classdef BEVProject_CheckProject_UnitTest < BEVTestCase
% Class implementation of unit test

% Copyright 2023 The MathWorks, Inc.

methods (Test)

function CheckProject(~)
  BEVProject_CheckProject
end

end  % methods (Test)
end  % classdef
