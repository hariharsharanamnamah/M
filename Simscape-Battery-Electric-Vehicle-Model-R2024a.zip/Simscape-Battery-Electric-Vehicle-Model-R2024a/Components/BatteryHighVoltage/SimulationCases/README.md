# Simulation Cases

In simulation case scripts,
referenced subsystems in the harness model are not changed
so that the scripts can be used with the harness model
with any referenced subsystems.

_Copyright 2022-2024 The MathWorks, Inc._
