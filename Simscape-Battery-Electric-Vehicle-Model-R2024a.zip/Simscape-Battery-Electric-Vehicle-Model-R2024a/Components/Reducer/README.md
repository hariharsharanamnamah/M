# Reducer Component

This is a road vehicle component representing
a reduction gear system sitting between motor and wheel axle.

_Copyright 2023 The MathWorks, Inc._
