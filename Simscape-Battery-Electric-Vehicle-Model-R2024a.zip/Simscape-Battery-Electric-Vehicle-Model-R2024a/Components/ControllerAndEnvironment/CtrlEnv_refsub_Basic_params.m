%% Parameters for Controller and Environment component
% If you edit this file, make sure to run this to update variables
% in the base workspace before running simulation.

% Copyright 2023 The MathWorks, Inc.

BEVController_refsub_Basic_params
