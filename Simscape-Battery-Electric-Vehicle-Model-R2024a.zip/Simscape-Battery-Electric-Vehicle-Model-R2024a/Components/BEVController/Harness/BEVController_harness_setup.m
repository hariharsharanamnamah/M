%% Setup script for BEV Controller
% This script is run automatically when harness model opens.
% If you edit this file, make sure to run this to update variables
% before running harness model for simulation.

% Copyright 2023 The MathWorks, Inc.

BEVController_refsub_Basic_params
