% This script opens Code Analyzer.
%
% Documentation
%
% - Code Analyzer
%   https://www.mathworks.com/help/matlab/ref/codeanalyzer-app.html

% Copyright 2024 The MathWorks, Inc.

codeAnalyzer(currentProject().RootFolder)
