# Utility for Vehicle Speed Reference component

## Test runner

`VehSpdRef_runtests.m` is a test runner function which runs all tests
for the component and generates a test summary and a code coverage report.

_Copyright 2024 The MathWorks, Inc._
