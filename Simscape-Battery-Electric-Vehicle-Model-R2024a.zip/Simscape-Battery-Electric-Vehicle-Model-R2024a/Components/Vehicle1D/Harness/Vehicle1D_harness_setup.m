%% Setup script for Vehicle1D component
% This script is run automatically when harness model opens.
% If you edit this file, make sure to run this to update variables
% before running harness model for simulation.

% Copyright 2020-2022 The MathWorks, Inc.

Vehicle1D_refsub_Basic_params
