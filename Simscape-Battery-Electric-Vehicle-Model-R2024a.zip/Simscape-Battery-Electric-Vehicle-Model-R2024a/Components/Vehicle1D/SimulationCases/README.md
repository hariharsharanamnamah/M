# Test Cases

In test case scripts,
referenced subsystems in the harness model are not changed
so that the scripts can be used for the harness model
containing any referenced subsystems.

*Copyright 2022 The MathWorks, Inc.*
