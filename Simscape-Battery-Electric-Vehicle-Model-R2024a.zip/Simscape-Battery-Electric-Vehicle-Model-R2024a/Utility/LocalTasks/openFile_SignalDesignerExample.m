% Copyright 2021-2022 The MathWorks, inc.

openFile("SignalDesigner_example.mlx")
