# Local tasks

Files in this folder are intended for use in the local machine.
They are not used in a remote workflow
such as a continuous integration (CI) pipeline.

_Copyright 2023-2024 The MathWorks, Inc._
