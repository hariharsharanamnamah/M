%% Setup script for Simple Vehicle component
% This script is run automatically when harness model opens.
% If you edit this file, make sure to run this to update variables
% before running harness model for simulation.

% Copyright 2023 The MathWorks, Inc.

CtrlEnv_Vehicle_refsub_params
